package Controller;

import model.Service.ReservaService;
import model.entity.Sala;
import model.entity.Usuario;
import model.repository.ReservaRepository;
import model.repository.SalaRepository;
import model.repository.UsuarioRepository;

import java.util.HashMap;

public class ReservaController {

    private final ReservaService service = new ReservaService();
    private final ReservaRepository repository;
    private final SalaRepository salaRepository;
    private final UsuarioRepository usuarioRepository;

    public ReservaController(ReservaRepository repository, SalaRepository salaRepository, UsuarioRepository usuarioRepository) {
        this.repository = repository;
        this.salaRepository = salaRepository;
        this.usuarioRepository = usuarioRepository;
    }

    public boolean cadastrar(int id, Usuario usuario, Sala sala, String data, String horario){
        return service.cadastrar(id, usuario, sala, data, horario, repository);
    }

    public HashMap<Integer, Sala> listarSalas(){
        return salaRepository.listar();
    }

    public HashMap<Integer, Usuario> listarUsuarios(){
        return usuarioRepository.listar();
    }
}
